import React from "react"
const Home = props => (
    <div>
        <h1>Inicial</h1>
    </div>
)
export default Home