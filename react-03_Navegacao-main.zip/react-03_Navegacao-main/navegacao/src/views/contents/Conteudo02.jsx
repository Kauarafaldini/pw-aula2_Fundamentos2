import React from "react"

const Conteudo02 = props => (
    <div>
        <h1>Conteúdo 02</h1>
    </div>
)

export default Conteudo02