import React from "react"

const NaoEncontrado = props => (
    <div>
        <h1>Página não encontrada</h1>
    </div>
)

export default NaoEncontrado