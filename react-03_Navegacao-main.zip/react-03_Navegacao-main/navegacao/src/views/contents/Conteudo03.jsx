import React from "react"

const Conteudo03 = props => (
    <div>
        <h1>Conteúdo 03</h1>
    </div>
)

export default Conteudo03